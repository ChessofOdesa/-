export const catalogItems =[
    {
        id: 1,
        title: "Aura Circle",
        description: "Мінімалістичне кругле дзеркало з LED-підсвіткою",
        price: "₴ 8,500",
        image: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?q=80&w=800&auto=format&fit=crop"
    },
    {
        id: 2,
        title: "Grand Elegance",
        description: "Підлогове дзеркало в тонкій золотій рамі",
        price: "₴ 14,200",
        image: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=800&auto=format&fit=crop"
    },
    {
        id: 3,
        title: "Infinity Edge",
        description: "Безрамне настінне дзеркало складної форми",
        price: "₴ 11,800",
        image: "https://images.unsplash.com/photo-1598928506311-c55dd1b65620?q=80&w=800&auto=format&fit=crop"
    },
    {
        id: 4,
        title: "Nordic Arch",
        description: "Дзеркало у формі арки для сучасного інтер'єру",
        price: "₴ 9,400",
        image: "https://images.unsplash.com/photo-1582582621959-48d27397dc69?q=80&w=800&auto=format&fit=crop"
    },
    {
        id: 5,
        title: "Lumina Oval",
        description: "Овальне дзеркало з сенсорним керуванням",
        price: "₴ 10,900",
        image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=800&auto=format&fit=crop"
    },
    {
        id: 6,
        title: "Royal Frame",
        description: "Ексклюзивне дзеркало з латунним профілем",
        price: "₴ 18,500",
        image: "https://images.unsplash.com/photo-1609115089333-3d0614cb20e9?q=80&w=800&auto=format&fit=crop"
    }
];

export const galleryImages =[
    "https://images.unsplash.com/photo-1618220179428-22790b46a0eb?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1600607688969-a5bfcd64bd40?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1617104424032-b9ab1e6c3821?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1600566752355-35792bedcfea?q=80&w=1000&auto=format&fit=crop"
];
